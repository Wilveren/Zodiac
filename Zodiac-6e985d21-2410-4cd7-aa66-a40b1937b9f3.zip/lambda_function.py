import json

print('Loading function')


def lambda_handler(event, context):
    month=event['month']
    day=int(event['day'])
    month = month.lower()
    month = month.strip()
    if  (isinstance(day, int)) and (day < 32) and (day >= 1): 
        if (month == 'december') and (day <= 31):
            astro_sign = 'Sagittarius' if (day < 22) else 'Capricorn'
        elif (month == 'january') and (day<=31):
            astro_sign = 'Capricorn' if (day < 20) else 'Aquarius'
        elif (month == 'february') and (day <=29):
            astro_sign = 'Aquarius' if (day < 19) else 'Pisces'
        elif (month == 'march') and (day<=31):
            astro_sign = 'Pisces' if (day < 21) else 'Aries'
        elif (month == 'april') and (day <=30):
            astro_sign = 'Aries' if (day < 20) else 'Taurus'
        elif (month == 'may') and (day <=31):
            astro_sign = 'Taurus' if (day < 21) else 'Gemini'
        elif (month == 'june') and (day <=30):
            astro_sign = 'Gemini' if (day < 21) else 'Cancer'
        elif (month == 'july') and (day <=31):
            astro_sign = 'Cancer' if (day < 23) else 'Leo'
        elif (month == 'august') and (day <= 31):
            astro_sign = 'Leo' if (day < 23) else 'Virgo'
        elif (month == 'september') and (day <=30):
            astro_sign = 'Virgo' if (day < 23) else 'Libra'
        elif (month == 'october') and (day <= 31):
            astro_sign = 'Libra' if (day < 23) else 'Scorpio'
        elif (month == 'november') and (day <= 30):
            astro_sign = 'Scorpio' if (day < 22) else 'Sagittarius'
        else:
            astro_sign = "None, because that's not a valid date."
    else:
        astro_sign = "None, because that's not a valid date."
    return{
        "result" : "Your Zodiac sign is: "+ astro_sign
    }
